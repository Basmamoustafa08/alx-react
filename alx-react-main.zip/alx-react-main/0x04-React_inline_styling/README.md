## 0x04. React inline styling
